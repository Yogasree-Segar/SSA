package DataStore;
//common datastore
public abstract class DataStore {

}
