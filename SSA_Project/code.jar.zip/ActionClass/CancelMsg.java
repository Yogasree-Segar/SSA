package ActionClass;
//super cancelMsg class
public abstract class CancelMsg {
	public abstract void cancelMsg();
}
