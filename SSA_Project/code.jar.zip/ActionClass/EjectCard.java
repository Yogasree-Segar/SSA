package ActionClass;
//super ejectcard class
public abstract class EjectCard {
	public abstract void ejectCard();
}
