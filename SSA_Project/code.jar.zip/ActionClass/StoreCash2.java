package ActionClass;
import DataStore.DataStore;

public class StoreCash2 extends StoreCash{
	
	public StoreCash2(DataStore data) {
		super(data);
	}

	@Override
	public void storeCash() {
		// TODO Auto-generated method stub
		
	}

}
