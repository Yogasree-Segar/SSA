package ActionClass;

public class ReturnCash2 extends ReturnCash{

	@Override
	public void returnCash() {
		// TODO Auto-generated method stub
		
	}

}
