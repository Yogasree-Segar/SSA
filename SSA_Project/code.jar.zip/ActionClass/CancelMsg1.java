package ActionClass;
//cancelmsg 1 for gp1
public class CancelMsg1 extends CancelMsg{

	@Override
	public void cancelMsg() {
		// TODO Auto-generated method stub
		System.out.println("Transaction Cancelled");
	}

}
