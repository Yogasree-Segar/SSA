package ActionClass;
//super class for wrongpinmsg extended by 2 classes for gp1 and gp2
public abstract class WrongPinMsg {
	public abstract void wrongPinMsg();
}
