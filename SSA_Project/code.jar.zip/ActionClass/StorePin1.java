package ActionClass;
import DataStore.DataStore;
public class StorePin1 extends StorePin{
	
	public StorePin1(DataStore data) {
		super(data);
	}

	@Override
	public void storePin() {
		// TODO Auto-generated method stub
		
	}

}
