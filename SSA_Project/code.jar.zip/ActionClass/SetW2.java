package ActionClass;
import DataStore.DataStore;

public class SetW2 extends SetW{
	
	public SetW2(DataStore data) {
		super(data);
	}

	@Override
	public void setW(int a) {
		// TODO Auto-generated method stub
		
	}

}
