package ActionClass;
//ejectcard2 for gp2 extending ejectcard
public class EjectCard2 extends EjectCard{

	@Override
	public void ejectCard() {
		// TODO Auto-generated method stub
		System.out.println("Debit pin verified correct");
		System.out.println("Card ejected");
	}

}
