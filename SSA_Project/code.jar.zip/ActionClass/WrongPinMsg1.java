package ActionClass;

public class WrongPinMsg1 extends WrongPinMsg{

	@Override
	public void wrongPinMsg() {
		// TODO Auto-generated method stub
		
	}

}
