package ActionClass;
//super enter pin msg
public abstract class EnterPinMsg {
	public abstract void enterPinMsg();
}
