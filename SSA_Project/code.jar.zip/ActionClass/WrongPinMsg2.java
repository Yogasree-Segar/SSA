package ActionClass;

public class WrongPinMsg2 extends WrongPinMsg {

	@Override
	public void wrongPinMsg() {
		// TODO Auto-generated method stub
		
	}

}
