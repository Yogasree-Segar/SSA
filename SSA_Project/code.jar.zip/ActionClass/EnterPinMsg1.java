package ActionClass;
//enterpinmsg1 for gp1 extending enterpinmsg
public class EnterPinMsg1 extends EnterPinMsg{

	@Override
	public void enterPinMsg() {
		// TODO Auto-generated method stub
		
	}

}
