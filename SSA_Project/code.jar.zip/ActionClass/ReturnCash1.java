package ActionClass;

public class ReturnCash1 extends ReturnCash{

	@Override
	public void returnCash() {
		// TODO Auto-generated method stub
		System.out.println("Remaining cash returned");
	}

}
