package ActionClass;

import DataStore.DataStore;


public class SetPrice1 extends SetPrice{

	public SetPrice1(DataStore data) {
		// TODO Auto-generated constructor stub
		super(data);
	}

	@Override
	public void setPrice(int a) {
		// TODO Auto-generated method stub
		
	}

}
