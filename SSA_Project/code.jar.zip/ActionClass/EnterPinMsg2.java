package ActionClass;
//enterpinmsg2 for gp2 extending enterpinmsg
public class EnterPinMsg2 extends EnterPinMsg{

	@Override
	public void enterPinMsg() {
		// TODO Auto-generated method stub
		System.out.println("Enter the pin");
	}

}
