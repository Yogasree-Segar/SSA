package ActionClass;

public class RejectMsg1 extends RejectMsg{

	@Override
	public void rejectMsg() {
		// TODO Auto-generated method stub
		System.out.println("Credit card rejected");
	}

}
