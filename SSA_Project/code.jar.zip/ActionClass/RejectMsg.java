package ActionClass;
//super class for reject msg extended by 2 classes for gp1 and gp2
public abstract class RejectMsg {
	public abstract void rejectMsg();
}
