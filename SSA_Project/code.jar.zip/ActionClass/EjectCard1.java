package ActionClass;
//ejectcard1 for gp1 extending ejectcard
public class EjectCard1 extends EjectCard{

	@Override
	public void ejectCard() {
		// TODO Auto-generated method stub
		System.out.println("Credit card accepted");
		System.out.println("Card ejected");
	}

}
