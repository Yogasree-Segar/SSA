package ActionClass;
//initializedata1 for gp1 extending initializedata
import DataStore.DataStore;

public class InitializeData1 extends InitializeData{

	public InitializeData1(DataStore data) {
		super(data);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void initializeData() {
		// TODO Auto-generated method stub
		
	}

}
