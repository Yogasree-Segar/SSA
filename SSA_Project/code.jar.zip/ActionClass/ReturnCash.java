package ActionClass;
//super class for returncash extended by 2 classes for gp1 and gp2
public abstract class ReturnCash {
	public abstract void returnCash();
}
