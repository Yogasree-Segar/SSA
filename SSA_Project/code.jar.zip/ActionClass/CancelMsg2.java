package ActionClass;
//cancelmsg2 for gp2
public class CancelMsg2 extends CancelMsg{

	@Override
	public void cancelMsg() {
		// TODO Auto-generated method stub
		System.out.println("Transaction Cancelled");
	}

}
