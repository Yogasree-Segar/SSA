package ActionClass;
//paymsg super class
public abstract class PayMsg {
	public abstract void payMsg();
}
